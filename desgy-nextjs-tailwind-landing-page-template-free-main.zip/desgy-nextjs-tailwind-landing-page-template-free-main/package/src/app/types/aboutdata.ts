export type aboutdata = {
  heading: string
  imgSrc: string
  paragraph: string
  link: string
}
