export type link = {
  label: string
  href?: string
}

export type footerlinks = {
  section: string
  links: link[]
}
