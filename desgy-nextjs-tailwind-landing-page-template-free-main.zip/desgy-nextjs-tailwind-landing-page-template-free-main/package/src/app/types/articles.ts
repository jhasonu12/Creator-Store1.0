export type articles = {
  time: string
  heading: string
  heading2: string
  date: string
  imgSrc: string
  name: string
}
