export type featureddata = { heading: string; imgSrc: string }
