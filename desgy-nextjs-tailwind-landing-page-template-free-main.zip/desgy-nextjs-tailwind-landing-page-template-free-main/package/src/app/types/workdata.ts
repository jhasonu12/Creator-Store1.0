export type workdata = { profession: string; name: string; imgSrc: string }
