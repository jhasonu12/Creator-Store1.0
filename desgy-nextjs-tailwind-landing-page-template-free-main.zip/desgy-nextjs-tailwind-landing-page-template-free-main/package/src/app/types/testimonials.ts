export type testimonials = {
  profession: string
  comment: string
  imgSrc: string
  name: string
  rating: number
}
